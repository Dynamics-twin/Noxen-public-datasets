# Noxen_Aerospace_Sample_Free

**100% SYNTHETIC — NO REAL DATA USED**

Ce dataset est entièrement généré par ordinateur. Aucune donnée, aucun
identifiant (immatriculation, code aéroport, numéro de série), aucun nom
de personne ou d'organisation ne provient d'une source réelle. Toute
ressemblance avec un appareil, une compagnie ou un événement réel est
purement fortuite et non intentionnelle.

## Contenu

- Édition : **SHOWCASE_FREE**
- Flotte simulée : 2 appareils
- Fenêtre d'exploitation simulée : 1 jours
- 18 tables, 3 798 lignes au total
- Format : CSV (UTF-8, en-tête sur la première ligne, horodatages ISO 8601)

| Table | Lignes | Clé primaire | Description |
|---|---:|---|---|
| `Airline` | 4 | `airline_id` | Compagnies aériennes synthétiques exploitant la flotte. |
| `Aircraft_Model` | 4 | `aircraft_model_id` | Classes de performance d'appareil (générique, non liées à un constructeur réel). |
| `Engine_Model` | 4 | `engine_model_id` | Classes de performance moteur associées aux modèles d'appareil. |
| `Airport` | 15 | `airport_id` | Aéroports synthétiques (codes IATA/ICAO-like réservés, jamais de collision avec un registre réel). |
| `Fault_Code` | 49 | `fault_code_id` | Référentiel de codes défaut par chapitre ATA simplifié. |
| `Part` | 156 | `part_id` | Catalogue de pièces (rotables, réparables, consommables). |
| `Supplier` | 4 | `supplier_id` | Fournisseurs de pièces synthétiques. |
| `Aircraft` | 2 | `aircraft_id` | Flotte d'appareils (immatriculation, modèle, compagnie, totaux cumulés). |
| `Technician` | 15 | `technician_id` | Techniciens de maintenance, licence et aéroport de base. |
| `Flight` | 12 | `flight_id` | Routes programmées (compagnie, origine, destination, fenêtre de validité). |
| `Weather` | 721 | `weather_id` | Observations météo par aéroport. |
| `Engine` | 4 | `engine_id` | Moteurs installés, rattachés à un appareil et à un modèle moteur. |
| `Flight_Segment` | 7 | `flight_segment_id` | Vols réellement opérés (horaires prévus/réels, retard, distance, consommation). |
| `Sensor_Reading` | 1 576 | `sensor_reading_id` | Télémétrie moteur et cellule, phase de vol par phase de vol — la table la plus volumineuse. |
| `Failure` | 202 | `failure_id` | Pannes détectées (moteur ou autre système), avec vérité terrain RUL pour les pannes moteur. |
| `Maintenance_Event` | 202 | `maintenance_event_id` | Interventions de maintenance déclenchées par une panne. |
| `Work_Order` | 356 | `work_order_id` | Ordres de travail détaillés au sein d'un événement de maintenance. |
| `Inventory` | 465 | `inventory_id` | Mouvements de stock de pièces (réception, sortie, ajustement). |

## Fichiers additionnels

- `metadata.json` — fiche technique machine-lisible (schéma, volumétrie,
  clés primaires/étrangères, paramètres de génération).
- `Dataset_Documentation.pdf` — documentation détaillée du schéma et des
  cas d'usage.
- `dataset/Sensor_Reading_quality_labels.csv` *(optionnel)* — étiquette de
  qualité par lecture (`NOMINAL`, `MISSING`, `FROZEN`, `DRIFTED`,
  `TRANSIENT_OUTLIER`, `SUSTAINED_ANOMALY`, `NOISE_INJECTED`). Ce fichier
  est fourni séparément du CSV principal `Sensor_Reading.csv` : les
  données réelles de terrain ne sont jamais pré-étiquetées, ce fichier
  sert exclusivement à l'entraînement/l'évaluation supervisée de modèles
  de détection d'anomalies, pas à la définition du dataset lui-même.

## Qualité des données

Ce dataset est délibérément **réaliste et non parfait** : valeurs
manquantes, doublons, dérive de capteur, capteurs figés, erreurs
d'horodatage, erreurs de saisie, identifiants occasionnellement erronés
(mais toujours valides — l'intégrité référentielle du schéma relationnel
est garantie), et bruit de mesure sont présents par construction. C'est
un choix de conception : un jeu de données synthétiques utile à
l'entraînement de modèles robustes doit refléter les défauts des données
de terrain réelles, pas seulement leur signal physique idéal.

L'intégrité STRUCTURELLE (clés primaires uniques, clés étrangères
résolvant toutes vers une ligne existante) est en revanche garantie à
100 % : ce dataset peut être chargé tel quel dans un moteur de base de
données relationnelle standard sans nettoyage préalable requis pour les
tests d'ingénierie de données, de schéma ou de requêtes.

## Utilisation prévue

- Entraînement de modèles d'IA/LLM/agents (maintenance prédictive,
  détection d'anomalies, prévision de durée de vie résiduelle, agents
  Text-to-SQL).
- Tests d'ingénierie de bases de données et de pipelines de données.
- Analyse exploratoire, tableaux de bord, démonstrations produit.

## Chargement rapide (Python)

```python
import pandas as pd

aircraft = pd.read_csv("dataset/Aircraft.csv")
sensor_reading = pd.read_csv("dataset/Sensor_Reading.csv", parse_dates=["ts"])
```
